  <?php
include 'header.php';
?>
<div class="slider">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/slide.png">
          </div>
        <div class="item">
            <img src="images/slide.png" >
        </div>
  </div>
<div class="caption2">
    <div class="container">
        <a href="index.php"> <h4>الرئيسيه</h4></a>
        <h3>ابحث عن وكيل </h3>
    </div>
</div>

</div>


  <div class="all">
    <div class="container">
      <div class="row">
          <div class="col-sm-9">
             <!--addrees1-->
              <h4>فورمة البحث</h4>
            <!--################ form #######-->
              <form>
                    <div class="form-group  pad-form">
                      <input type="text" class="form-control" id="search" placeholder="أكتب اسم الوكيل">
                    </div>
                    <div class="input-button pad-form">
                       <div class="form-group">
                           <button class="color-red">بحث</button>
                        </div>
                    </div>
              </form>
              <h4 class="mart">نتائج البحث</h4>
              <label class="padt">1نتائج متوفرة</label>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="card">
                           <a href="#">
                            <img src="images/user.png">
                            <span class="col">محمد على</span>
                            <span>0155788996517</span>
                            <span>info@yaya.com</span>
                          </a>
                      </div>
                   </div>
               </div>
           </div>
          
            <!--################### side #################-->
          
          <div class="col-sm-3">
            <aside>
                              <!--addrees1-->
              <h4>دخول الأعضاء</h4>
                <!--form-->
                <form>
                  <input type="text" placeholder="اسم المستخدم">
                  <input type="password" placeholder="كلمة المرور">
                  <input type="checkbox"><span>تذكيرى</span>
                  <a href="#">هل نسيت كلمة السر؟</a>
                    <div class="butt">
                       <button class="color-blue pad">دخول</button>
                       <button class="color-red">انضم إلينا</button>
                    </div>
                </form>
                                    <!--  انضم الينا-->
                <div class="event-slide">
                   <img src="images/im1.png">
                      <div class="come">
                        <span>أنضم</span>
                        <h3>إلينا الآن</h3>
                      </div>
                </div>

            </aside>
          </div>
      </div>
    </div>
  </div>

  <?php
include 'footer.php';
?>


