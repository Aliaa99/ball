  <?php
include 'header.php';
?>
<div class="slider">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/slide.png">
          </div>
        <div class="item">
            <img src="images/slide.png" >
        </div>
  </div>
<div class="caption2">
    <div class="container">
        <a href="index.php"> <h4>الرئيسيه</h4></a>
        <h3>تسجيل</h3>
    </div>
</div>

</div>


  <div class="all">
    <div class="container">
      <div class="row">
          <div class="col-sm-9">
             <!--addrees1-->
              <h4>معلومات شخصية</h4>
              <div class="profile">
                <div class="row">
                  <div class="col-xs-2 center">
                     <img src="images/pro.png">
                  </div>
                  <div class="col-xs-8">
                      <h3>محمد أحمد</h3>
                      <span>السعودية</span>
                  </div>
                </div>
                  <div class="info">
                      <div class="row">
                        <div class="col-sm-4">
                            <label>الايميل:</label>
                            <span>aliaaahmed@gmail.com</span>
                        </div>
                        <div class="col-sm-4">
                            <label>المدينة</label>
                            <span>الرياض</span>
                        </div>
                        <div class="col-sm-4">
                            <label>الهاتف</label>
                            <span>+92000025177878</span>
                        </div>
                      </div>
                  </div>
                     <button class="color-red">تعديل بياناتى</button>

<!--تعديلات-->
                     <button class="color-red marg">ألبوم الصور</button>
                     <button class="color-red marg">ألبوم الفديوهات</button>
<!--تعديلات-->
              </div>
              
                <!-- address2 -->
              
              <h4>رفع صور وفيديو</h4>
              <div class="profile2">
              <form>
                <div class="row">
                    <div class="form-group col-sm-6 pad-form">
                      <label for="pic1">رفع صورة رئيسية</label>
                      <input type="file" class="form-control" id="pic1">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="pic2">رفع صورة فرعية</label>
                      <input type="file" class="form-control" id="pic2">
                        <a href="#"><i class="fa fa-plus" aria-hidden="true"></i></a>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="vedio">رفع فيديو</label>
                      <input type="file" class="form-control" id="vedio">
                        <a href="#"><i class="fa fa-plus" aria-hidden="true"></i></a>
                    </div>
                  </div>
              </form>
              </div>

           </div>
          
            <!--################### side #################-->
          
          <div class="col-sm-3">
            <aside>
                              <!--addrees1-->
              <h4>دخول الأعضاء</h4>
                <!--form-->
                <form>
                  <input type="text" placeholder="اسم المستخدم">
                  <input type="password" placeholder="كلمة المرور">
                  <input type="checkbox"><span>تذكيرى</span>
                  <a href="#">هل نسيت كلمة السر؟</a>
                    <div class="butt">
                       <button class="color-blue pad">دخول</button>
                       <button class="color-red">انضم إلينا</button>
                    </div>
                </form>
            </aside>
          </div>
      </div>
    </div>
  </div>

  <?php
include 'footer.php';
?>


