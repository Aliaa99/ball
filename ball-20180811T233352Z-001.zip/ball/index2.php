  <?php
include 'header.php';
?>

<div class="slider">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/slide.png">
               <div class="container">
                  <div class="caption">
                    <h4 class="animated rotateIn">أكبر تجمع رياضى</h4>
                    <h3  class="animated bounceIn">يقدم المواهب الصاعدة في كرة القدم والألعاب الأخرى</h3>
                 </div>
              </div>
          </div>
        <div class="item">
            <img src="images/slide.png" >
               <div class="container">
                  <div class="caption">
                    <h4 class="animated rotateIn">أكبر تجمع رياضى</h4>
                    <h3  class="animated bounceIn">يقدم المواهب الصاعدة في كرة القدم والألعاب الأخرى</h3>
                 </div>
              </div>
          </div>
  </div>
</div>

<!--############ news ############-->

  <div class="all">
    <div class="container">
      <div class="row">
          <div class="col-sm-9">
                    <!--addrees1-->
              <h4>أحدث الأخبار والفعاليات</h4>
                    <!--slider1-->
              <div class="event-slide">
                        <img src="images/s1.png">
              </div>
                        <!-- news-->
              <div class="all-news">
                <div class="news">
                <a href="#">
                  <h5>الأخضر يغادر إلى بروكسل لمواجهة بلجيكا</h5>
                  <p>غادرت بعثة المنتخب السعودي الأول لكرة القدم اليوم الأحد، مدينة ماربيا الإسبانية إلى العاصمة البلجيكية بروكسل، وذلك استعدادًا لمواجهة منتخب بلجيكا بعد غدٍ الثلاثاء، ضمن استعدادات الأخضر للمشاركة في مونديال كأس العالم في روسيا الصيف المقبل.
                      وتأتي المباراة في إطار المرحلة الثالثة من البرانامج الإعدادي للأخضر، والتي بدأت في مدينة ماربيا الإسبانية، والتقى خلالها الأخضر نظيره الأوكراني، وانتهت المباراة بالتعادل الإيجابي  ...</p>
                </a>
                  
              </div>
                <div class="news">
                 <a href="#">
                  <h5>الهلال في تبوك.. وإدواردو يصل قبل الأهلي</h5>
                    <p>أعطت إدارة نادي الهلال اللجنة المنظمة لبطولة تبوك الدولية الودية موافقتها على المشاركة في النسخة الثالثة من بطولة تبوك الدولية الودية لكرة القدم نهاية يوليو المقبل ...</p>
                  </a>
              </div>
                <div class="news">
                <a href="#">
                  <h5>اتحاد القدم يخطط على جوارديولا وفيرجسون</h5>
                  <p>كشف لـ "الرياضية" تركي السلطان، عضو اللجنة الفنية في برنامج التعليم المستمر لتطوير المدربين السعوديين في اتحاد القدم، عن نية جهته الاستعانة بالإسباني بيب جوارديولا، والإسكتلندي ...</p>
                </a>
              </div>
              </div>
              
              <a href="#" class="to-all">أقرأ المزيد</a>
              
          <!-- ################## second section news ######################-->
                    <!--addrees2-->
              <h4>أحدث المقالات</h4>
                    <!--slider2-->
              <div class="event-slide">
                        <img src="images/s2.png">
              </div>
                        <!-- news-->
              <div class="all-news">
                <div class="news">
                <a href="#">
                  <h5>الأخضر يغادر إلى بروكسل لمواجهة بلجيكا</h5>
                  <p>غادرت بعثة المنتخب السعودي الأول لكرة القدم اليوم الأحد، مدينة ماربيا الإسبانية إلى العاصمة البلجيكية بروكسل، وذلك استعدادًا لمواجهة منتخب بلجيكا بعد غدٍ الثلاثاء، ضمن استعدادات الأخضر للمشاركة في مونديال كأس العالم في روسيا الصيف المقبل.
                      وتأتي المباراة في إطار المرحلة الثالثة من البرانامج الإعدادي للأخضر، والتي بدأت في مدينة ماربيا الإسبانية، والتقى خلالها الأخضر نظيره الأوكراني، وانتهت المباراة بالتعادل الإيجابي  ...</p>
                </a>
                  
              </div>
                <div class="news">
                 <a href="#">
                  <h5>الهلال في تبوك.. وإدواردو يصل قبل الأهلي</h5>
                    <p>أعطت إدارة نادي الهلال اللجنة المنظمة لبطولة تبوك الدولية الودية موافقتها على المشاركة في النسخة الثالثة من بطولة تبوك الدولية الودية لكرة القدم نهاية يوليو المقبل ...</p>
                  </a>
              </div>
                <div class="news">
                <a href="#">
                  <h5>اتحاد القدم يخطط على جوارديولا وفيرجسون</h5>
                  <p>كشف لـ "الرياضية" تركي السلطان، عضو اللجنة الفنية في برنامج التعليم المستمر لتطوير المدربين السعوديين في اتحاد القدم، عن نية جهته الاستعانة بالإسباني بيب جوارديولا، والإسكتلندي ...</p>
                </a>
              </div>
              </div>
              
              <a href="#" class="to-all">أقرأ المزيد</a>
              
           </div>
          
            <!--################### side #################-->
          
          <div class="col-sm-3">
            <aside>
                              <!--addrees1-->
              <h4>دخول الأعضاء</h4>
                <!--form-->
                <div class="card2">
                    <img src="images/user.png">
                    <div class="inf2">
                        <span class="name-pro">محمد أحمد</span>
                        <span>السعودية</span>
                        <span>125889947566</span>
                    </div>
                    <div class="butt">
                       <button class="color-blue">حسابى</button>
                       <button class="color-red">المركز الاعلامى</button>
                    </div>
                </div>
                    <!--  انضم الينا-->
                <div class="event-slide">
                   <img src="images/im1.png">
                      <div class="come">
                        <span>أنضم</span>
                        <h3>إلينا الآن</h3>
                      </div>
                </div>
                    <!--dopdown-->
                <div class="drop-slide">
                  <div class="dropdown">
                    <button class="btn  dropdown-toggle" type="button" data-toggle="dropdown">المركز الاعلامى
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                      <li><a href="#">مركز1</a></li>
                      <li><a href="#">مركز2</a></li>
                    </ul>
                  </div>
                </div>
                
                <!-- اعلانات-->
                 <div class="event-slide">
                   <img src="images/im2.png">
                      <div class="go">
                        <span>اعلان</span>
                      </div>
                </div>
            </aside>
          </div>
      </div>
    </div>
  </div>

  <?php
include 'footer.php';
?>


