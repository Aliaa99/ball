  <?php
include 'header.php';
?>
<div class="slider">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/slide.png">
          </div>
        <div class="item">
            <img src="images/slide.png" >
        </div>
  </div>
<div class="caption2">
    <div class="container">
        <a href="index.php"> <h4>الرئيسيه</h4></a>
        <h3>الدفع </h3>
    </div>
</div>

</div>


  <div class="all">
    <div class="container">
      <div class="row">
          <div class="col-sm-9">
             <!--addrees1-->
              <h4>طرق الدفع</h4>
              
                <!-- pay -->
              <div class="pay">
                 <a href="#"><img src="images/v2.png"></a>
                 <a href="#"><img src="images/v1.png"></a>
              </div>
           </div>
          
            <!--################### side #################-->
          
          <div class="col-sm-3">
            <aside>
                              <!--addrees1-->
              <h4>دخول الأعضاء</h4>
                <!--form-->
                <form>
                  <input type="text" placeholder="اسم المستخدم">
                  <input type="password" placeholder="كلمة المرور">
                  <input type="checkbox"><span>تذكيرى</span>
                  <a href="#">هل نسيت كلمة السر؟</a>
                    <div class="butt">
                       <button class="color-blue pad">دخول</button>
                       <button class="color-red">انضم إلينا</button>
                    </div>
                </form>
                                    <!--  انضم الينا-->
                <div class="event-slide">
                   <img src="images/im1.png">
                      <div class="come">
                        <span>أنضم</span>
                        <h3>إلينا الآن</h3>
                      </div>
                </div>

            </aside>
          </div>
      </div>
    </div>
  </div>

  <?php
include 'footer.php';
?>


