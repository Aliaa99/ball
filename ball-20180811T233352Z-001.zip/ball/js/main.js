////menu
//
//$(document).ready(function(){
//    $('.main .op').click(function(){
//        $('.menu2').css({"width":"70%",})
//        $('.main').css({"right":"70%",})
//        $(this).toggle();
//        $('.main span').toggle();
//
//    });
//    $('.menu2 .clo').click(function(){
//        $(this).parent().css({"width":"0",})
//        $('.main').css({"right":"0",})
//        $('.main .op').toggle();
//        $('.main span').toggle();
//    });
//        $('.opop').click(function(){
//        $('.men').slideToggle();
//    });
//
//});
//
//
//                    //scroll top
//
//$('.bottom-nav a').click (function(){
//      $('html,body').animate({
//          scrollTop:$("#down").offset().top},1000);
//   });
//    
//
//
//
//
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    rtl:true,
    dots:false,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1
        }
    }
});

    //fancy box
    $('.various').fancybox({
        padding : 10,
        openEffect  : 'fade'
    });





