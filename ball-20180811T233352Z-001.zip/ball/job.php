  <?php
include 'header.php';
?>
<div class="slider">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/slide.png">
          </div>
        <div class="item">
            <img src="images/slide.png" >
        </div>
  </div>
<div class="caption2">
    <div class="container">
        <a href="index.php"> <h4>الرئيسيه</h4></a>
        <h3>التوظيف</h3>
    </div>
</div>

</div>


  <div class="all">
    <div class="container">
      <div class="row">
          <div class="col-sm-9">
             <!--addrees1-->
              <h4>ملئ الفورمة</h4>
            <!--################ form #######-->
              <form>
                <div class="row">
                    <div class="form-group col-sm-6 pad-form">
                      <label for="name3">الاسم </label>
                      <input type="text" class="form-control" id="name3" placeholder=" الاسم">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="mail3">البريد الالكترونى</label>
                          <select class="form-control" id="mail3">
                            <option  value="" hidden>البريد الالكترونى</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="country3">الدولة</label>
                          <select class="form-control" id="country3">
                            <option  value="" hidden>الدولة</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="number3">الجوال</label>
                      <input type="text" class="form-control" id="number3" placeholder="الجوال">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="job1">الوظيفة</label>
                          <select class="form-control" id="job1">
                            <option  value="" hidden>الوظيفة</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="cv">ارفاق السيرة الذاتية</label>
                      <input type="file" class="form-control" id="cv">
                    </div>
                    <div class="form-group col-sm-12 pad-form">
                      <label for="letter1">مقدمة الخطاب</label>
                      <textarea id="letter1" rows="8" class="book"></textarea>
                    </div>
                    <div class="input-button  col-sm-12 pad-form">
                       <div class="form-group">
                           <button class="color-red">ارسال</button>
                        </div>
                    </div>

                  </div>
              </form>

           </div>
          
            <!--################### side #################-->
          
          <div class="col-sm-3">
            <aside>
                              <!--addrees1-->
              <h4>دخول الأعضاء</h4>
                <!--form-->
                <form>
                  <input type="text" placeholder="اسم المستخدم">
                  <input type="password" placeholder="كلمة المرور">
                  <input type="checkbox"><span>تذكيرى</span>
                  <a href="#">هل نسيت كلمة السر؟</a>
                    <div class="butt">
                       <button class="color-blue pad">دخول</button>
                       <button class="color-red">انضم إلينا</button>
                    </div>
                </form>
                                    <!--  انضم الينا-->
                <div class="event-slide">
                   <img src="images/im1.png">
                      <div class="come">
                        <span>أنضم</span>
                        <h3>إلينا الآن</h3>
                      </div>
                </div>

            </aside>
          </div>
      </div>
    </div>
  </div>

  <?php
include 'footer.php';
?>


