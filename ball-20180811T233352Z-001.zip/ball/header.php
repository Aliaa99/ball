<!DOCTYPE html>
<html lang="en">
<head>
  <title>web-page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/lightbox.css">
  <link rel="shortcut icon" href="images/logo.png">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/stylesheet.css">

</head>
<body>

<header>
   <div class="navpro">
    <div class="upnav">
       <div class="container">
         <div class="row">
               <div class="col-sm-6">
                    <img src="images/logo.png">
                </div>
                <div class="col-sm-6">
                    <div class="col-md-6 col-md-offset-2 col-sm-6 mar-t">
                          <input type="search" placeholder="بحث"><i class="fa fa-search navsearch" aria-hidden="true"></i>
                    </div>
                     <div class="col-md-4 col-sm-6 mar-t2">
                         <a href="#" class="social google"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                         <a href="#" class="social tweter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                         <a href="#" class="social facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
         </div>
    </div>
            <nav class="navbar navbar-inverse">
              <div class="container">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                  </button>
                  <a class="navbar-brand" href="#"></a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav">
                    <li class="active"><a href="#">الرئيسية</a></li>
                    <li><a href="#">الرياضة</a></li>
                    <li><a href="#">من نحن</a></li>
                    <li><a href="#">خدمات</a></li>
                    <li><a href="#">الحصول على وكيل محلى</a></li>
                    <li><a href="#">تسجيل دخول</a></li>
                    <li><a href="#">تواصل معنا</a></li>
                  </ul>
                  <ul class="nav navbar-nav navbar-left">
                    <li class="dropdown">
                        <a class="dropdown-toggle lang" data-toggle="dropdown" href="#">اللغة <span class="caret"></span></a>
                          <ul class="dropdown-menu">
                            <li><a href="#"><img src="images/arabic.png">اللغة العربية</a></li>
                            <li><a href="#"><img src="images/eng.png">اللغة الانجليزيه</a></li>
                          </ul>
                      </li>
                  </ul>
                </div>
              </div>
            </nav>
        </div>
</header>


