<!--##################### footer ##################-->

<footer>
    <div class="up-footer">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <img src="images/logo2.png">
            </div>
            <div class="col-sm-5 col-sm-offset-1">
                <input type="email" placeholder="أضع بريدك ليصلك جديد الموقع" >
                <img src="images/mail.png" class="send-mail">
              </div>
          </div>
        </div>
    </div>
    <div class="down-footer">
        <div class="container">
        <div class="row">
           <div class="col-sm-6 col-lg-4 col-md-4">
             <h3>روابط مهمه</h3>
             <ul class="ulone">
                <li><a href="#">الرئيسية</a></li>
                <li><a href="#">الاخبار والفاعليات</a></li>
                <li><a href="#">من نحن</a></li>
                <li><a href="#">المركز الاعلامى</a></li>
                <li><a href="#">الفرص</a></li>
                <li><a href="#">اسئلة شائعة</a></li>
                <li><a href="#">المجتمع</a></li>
                <li><a href="#">تواصل معنا</a></li>
             </ul>
          </div>
           <div class="col-sm-6 col-lg-4 col-md-3">
               <h3>معلومات</h3>
             <ul class="ultwo">
                <li><a href="#">اخلاء المسئولية</a></li>
                <li><a href="#">سياسة الخصوصية</a></li>
                <li><a href="#">سياسة التعامل</a></li>
                <li><a href="#">شروط الاستخدام</a></li>
             </ul>
           </div>
           <div class="col-sm-6 col-lg-4 col-md-5">
               <h3>تابعنا</h3>
                <div class="col-sm-12 height">    
                   <!-- Facebook page insert -->
                   <div class="face-page-insert">
                   <div class="fb-page" data-href="https://www.facebook.com/facebook" data-tabs="timeline" data-width="320px" data-height="300px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/facebook" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote></div>                       
                  </div>
                </div>
           </div>
        </div>
        <div class="finish">
           <div class="row">
             <div class="col-xs-6">
                جميع الحقوق محفوظة 2018
             </div>
             <div class="col-xs-6 leftdir">
                 تصميم وبرمجة:<span>براند</span>
             </div>
           </div>
        </div>
    </div>
  </div>
</footer>


    <div id="fb-root"></div>
       <script>(function(d, s, id) {
         var js, fjs = d.getElementsByTagName(s)[0];
         if (d.getElementById(id)) return;
         js = d.createElement(s); js.id = id;
         js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.12';
         fjs.parentNode.insertBefore(js, fjs);
       }(document, 'script', 'facebook-jssdk'));</script>

    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
<!--    <script type="text/javascript" src="libs/js/bootstrap.js"></script>-->
<!--    <script type="text/javascript" src="libs/js/wow.min.js"></script>-->
    <script src="js/jquery.carousel.js"></script>
    <script src="js/lightbox.js"></script>
    <script type="text/javascript" src="js/main.js"></script>

</body>
</html>