  <?php
include 'header.php';
?>
<div class="slider">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/slide.png">
          </div>
        <div class="item">
            <img src="images/slide.png" >
        </div>
  </div>
<div class="caption2">
    <div class="container">
        <a href="index.php"> <h4>الرئيسيه</h4></a>
        <h3>تسجيل</h3>
    </div>
</div>

</div>


  <div class="all">
    <div class="container">
      <div class="row">
          <div class="col-sm-9">
             <!--addrees1-->
              <h4>معلومات شخصية</h4>
            <!--################ form #######-->
              <form>
                <div class="row">
                    <div class="form-group col-sm-6 pad-form">
                      <label for="name2">الاسم بالكامل</label>
                      <input type="text" class="form-control" id="name2" placeholder="بالكامل الاسم">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="nationality2">الجنسية</label>
                          <select class="form-control" id="nationality2">
                            <option  value="" hidden>الجنسية</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="date2">تاريخ الميلاد</label>
                      <input type="datetime" class="form-control" id="date2" placeholder="تاريخ الميلاد">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="kind2">الفئة</label>
                          <select class="form-control" id="kind2">
                            <option  value="" hidden>محترف</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="address2">العنوان</label>
                      <input type="text" class="form-control" id="address2" placeholder="العنوان">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="share1">نوع الاشتراك</label>
                          <select class="form-control" id="share1">
                            <option  value="" hidden>لاعب</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="number1">رقم الجوال</label>
                      <input type="text" class="form-control" id="number1" placeholder="رقم الجوال">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="club1">النادى</label>
                      <input type="text" class="form-control" id="club1" placeholder="النادى">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="match1">عدد المباريات</label>
                      <input type="text" class="form-control" id="match1" placeholder="عدد المباريات">
                    </div>

                    <div class="input-button  col-sm-12 pad-form">
                       <div class="form-group">
                           <button class="color-red">انضم الان</button>
                        </div>
                    </div>
                  </div>
              </form>

           </div>
          
            <!--################### side #################-->
          
          <div class="col-sm-3">
            <aside>
                              <!--addrees1-->
              <h4>دخول الأعضاء</h4>
                <!--form-->
                <form>
                  <input type="text" placeholder="اسم المستخدم">
                  <input type="password" placeholder="كلمة المرور">
                  <input type="checkbox"><span>تذكيرى</span>
                  <a href="#">هل نسيت كلمة السر؟</a>
                    <div class="butt">
                       <button class="color-blue pad">دخول</button>
                       <button class="color-red">انضم إلينا</button>
                    </div>
                </form>
            </aside>
          </div>
      </div>
    </div>
  </div>

  <?php
include 'footer.php';
?>


