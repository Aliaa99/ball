  <?php
include 'header.php';
?>
<div class="slider">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="images/slide.png">
          </div>
        <div class="item">
            <img src="images/slide.png" >
        </div>
  </div>
<div class="caption2">
    <div class="container">
        <a href="index.php"> <h4>الرئيسيه</h4></a>
        <h3>تواصل معنا</h3>
    </div>
</div>

</div>


  <div class="all">
    <div class="container">
      <div class="row">
          <div class="col-sm-9">
             <!--addrees1-->
              <h4>ارسال رسالة</h4>
            <!--################ form #######-->
              <form>
                <div class="row">
                    <div class="form-group col-sm-6 pad-form">
                      <label for="name4">الاسم </label>
                      <input type="text" class="form-control" id="name4" placeholder=" الاسم">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="mail4">البريد الالكترونى</label>
                          <select class="form-control" id="mail4">
                            <option  value="" hidden>البريد الالكترونى</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="country4">الدولة</label>
                          <select class="form-control" id="country4">
                            <option  value="" hidden>الدولة</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="number4">الجوال</label>
                      <input type="text" class="form-control" id="number4" placeholder="الجوال">
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                       <label for="job2">الوظيفة</label>
                          <select class="form-control" id="job2">
                            <option  value="" hidden>الوظيفة</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                    </div>
                    <div class="form-group col-sm-6 pad-form">
                      <label for="company4">الشركة</label>
                      <input type="text" class="form-control" id="company4" placeholder="الشركة">
                    </div>
                    <div class="form-group col-sm-12 pad-form">
                      <label for="mess4">الرسالة</label>
                      <textarea id="mess4" rows="8" class="book"></textarea>
                    </div>
                    <div class="input-button  col-sm-12 pad-form">
                       <div class="form-group">
                           <button class="color-red">ارسال</button>
                        </div>
                    </div>

                  </div>
              </form>
                    <!--معلومات التواصل-->
              <h4>معلومات التواصل</h4>
              <div class="pading">
                  <div class="row">
                    <div class="col-sm-3">
                        <a href="#">
                         <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
                         <span>info@fcsiagency.com</span>
                        </a>
                      </div>
                      <div class="col-sm-3 col-sm-offset-1">
                        <a href="#">
                         <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                         <span>0545218563</span>
                        </a>
                      </div>
                    <div class="col-sm-4 center padtop">
                        <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                      </div>
                  </div>
              </div>
           </div>
          
            <!--################### side #################-->
          
          <div class="col-sm-3">
            <aside>
                              <!--addrees1-->
              <h4>دخول الأعضاء</h4>
                <!--form-->
                <form>
                  <input type="text" placeholder="اسم المستخدم">
                  <input type="password" placeholder="كلمة المرور">
                  <input type="checkbox"><span>تذكيرى</span>
                  <a href="#">هل نسيت كلمة السر؟</a>
                    <div class="butt">
                       <button class="color-blue pad">دخول</button>
                       <button class="color-red">انضم إلينا</button>
                    </div>
                </form>
                                    <!--  انضم الينا-->
                <div class="event-slide">
                   <img src="images/im1.png">
                      <div class="come">
                        <span>أنضم</span>
                        <h3>إلينا الآن</h3>
                      </div>
                </div>

            </aside>
          </div>
      </div>
    </div>
  </div>

  <?php
include 'footer.php';
?>


